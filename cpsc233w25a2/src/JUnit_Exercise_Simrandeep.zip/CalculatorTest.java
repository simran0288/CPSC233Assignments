import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class CalculatorTest {

    Calculator calculator;

    @BeforeEach
    public void setUp() {
        calculator = new Calculator();
    }

    @AfterEach
    public void tearDown() {
        calculator = null;
    }

    @Test
    public void testAddition() {
        assertEquals(10.0, calculator.addition(5, 5));
        assertEquals(-2.0, calculator.addition(-1, -1));
        assertEquals(0.0, calculator.addition(3, -3));
    }

    @Test
    public void testSubtraction() {
        assertEquals(0.0, calculator.subtraction(5, 5));
        assertEquals(-2.0, calculator.subtraction(-1, 1));
        assertEquals(6.0, calculator.subtraction(3, -3));
    }

    @Test
    public void testMultiplication() {
        assertEquals(25.0, calculator.multiplication(5, 5));
        assertEquals(1.0, calculator.multiplication(-1, -1));
        assertEquals(-9.0, calculator.multiplication(3, -3));
    }

    @Test
    public void testDivision() {
        assertEquals(1.0, calculator.divide(5, 5));
        assertEquals(3.0, calculator.divide(9, 3));
        assertEquals(-2.0, calculator.divide(6, -3));
    }

    @Test
    public void testDivideByZero() {
        assertThrows(ArithmeticException.class, () -> calculator.divide(5, 0));
    }

    @ParameterizedTest
    @CsvSource({
            "2, true",
            "3, false",
            "10, true",
            "11, false"
    })
    void testIsEven(int input, boolean expected) {
        assertEquals(expected, Calculator.isEven(input));
    }
}
